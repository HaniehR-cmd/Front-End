const menu = document.querySelector('.filter');
const buttons = document.querySelectorAll('.filter button');
const line = document.querySelector('.line');
const products = document.querySelectorAll('.products');

function changeCategory(button, category) {
   
  
    // حذف کلاس فعال از همه دکمه‌ها و محصولات
    buttons.forEach(btn => btn.classList.remove('active'));
    products.forEach(prod => prod.classList.remove('active'));

    // افزودن کلاس فعال به دکمه و محصول انتخابی
    button.classList.add('active');
    document.getElementById(category).classList.add('active');

    // تنظیم خط زیر دکمه فعال
    const buttonRect = button.getBoundingClientRect();
    const menuRect = menu.getBoundingClientRect();
    line.style.width = buttonRect.width + 'px'; // عرض خط
    line.style.left = (buttonRect.left - menuRect.left) + 'px'; // موقعیت خط
} 
    window.onload = () => {
        const activeButton = document.querySelector('.filter button.active');
        const buttonRect = activeButton.getBoundingClientRect();
        const menuRect = menu.getBoundingClientRect();
        line.style.width = buttonRect.width + 'px';
        line.style.left = (buttonRect.left - menuRect.left) + 'px';
    };