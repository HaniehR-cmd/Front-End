function startCounting(element) {
    let target = parseInt(element.getAttribute("data-count"));
    let current = 0;
    let speed = 50; //z
    let interval = setInterval(() => {
        if (current < target) {
            current += Math.ceil(target / 100); 
            element.innerText = current;
        } else {
            element.innerText = target;
            clearInterval(interval);
        }
    }, speed);
}

let observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            startCounting(entry.target);
            observer.unobserve(entry.target); 
        }
    });
});

document.querySelectorAll(".counter").forEach(counter => {
    observer.observe(counter);
});
const links = document.querySelectorAll('.scroll-link');

  links.forEach(link => {
      link.addEventListener('click', function(e) {
          e.preventDefault();

          const targetId = this.getAttribute('href');
          const targetElement = document.querySelector(targetId);
          const headerOffset = 100; 
          const elementPosition = targetElement.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

          window.scrollTo({
              top: offsetPosition,
              behavior: 'smooth'
          });
      });
  });
  function showProducts(category) {
    document.querySelectorAll('.products').forEach(div => {
        div.classList.remove('active');
        div.style.display = 'none';
    });
    const selectedDiv = document.getElementById(category);
    if (selectedDiv) {
        selectedDiv.classList.add('active');
        selectedDiv.style.display = 'flex';  
    }
}


let groups = document.querySelectorAll('.comment-group');
let currentGroup = 0;

setInterval(() => {
  groups[currentGroup].classList.remove('active');
  currentGroup = (currentGroup + 1) % groups.length;
  groups[currentGroup].classList.add('active');
}, 5000); // Every 5 seconds


