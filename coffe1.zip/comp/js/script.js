
const swiper = new Swiper('.swiper', {
    // modules: [Navigation, A11y],
    direction: 'horizontal',
    loop: false,
    navigation: {
      nextEl: '.c-carousel__button--next',
      prevEl: '.c-carousel__button--prev',
    },
    slidesPerView: 'auto',
    spaceBetween: 48,
    a11y: {
      prevSlideMessage: 'Previous slide',
      nextSlideMessage: 'Next slide',
    },
  });
  const links = document.querySelectorAll('.scroll-link');

  links.forEach(link => {
      link.addEventListener('click', function(e) {
          e.preventDefault();

          const targetId = this.getAttribute('href');
          const targetElement = document.querySelector(targetId);

          const headerOffset = 100; // ارتفاع هدر ثابت
          const elementPosition = targetElement.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

          window.scrollTo({
              top: offsetPosition,
              behavior: 'smooth'
          });
      });
  });
function lan(){
     document.body.style.direction='ltr';   
}